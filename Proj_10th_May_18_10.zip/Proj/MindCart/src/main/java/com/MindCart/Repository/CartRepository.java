package com.MindCart.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.UsersEntity;

@Repository
public interface CartRepository extends JpaRepository<CartEntity, Long>{
	
	/*@Query(value = "select user from UsersEntity user where user.userName=:userName and user.password=:password")
	public UsersEntity findUser(@Param("userName") String userName, @Param("password") String password);
	*/
	/*@Query(value = "select * from MINDCARTUSER where ")
	public UsersEntity findUser(@Param("userName") String userName, @Param("password") String password);*/
	
	@Query(value = "select * from CART user where user.USER_ID= ?", nativeQuery=true)
	public CartEntity findUserR(long userId);
	
	@Query(value = "select * from CART", nativeQuery=true)
	public List<CartEntity> findAllUsers();

	@Query(value = "select * from CART user where user.USER_ID= ?", nativeQuery=true)
	public CartEntity findCartByUserId(long userId);

}
