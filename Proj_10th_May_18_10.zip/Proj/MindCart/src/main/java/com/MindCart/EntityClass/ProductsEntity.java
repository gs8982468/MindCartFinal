package com.MindCart.EntityClass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ALL_PRODUCT_LIST")
//@NamedQuery(name = "UsersEntity.findAll", query="select user from UsersEntity user")
public class ProductsEntity {
	

	@Id
	@Column(name = "PRODUCT_ID")
	private long productId;
	
	@Column(name = "PRODUCT_NAME")
	private String productName;
	
	@Column(name = "SELLER")
	private String seller;
	

	@Column(name = "PRICE")
	private int price;

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!(obj instanceof ProductsEntity)) {
			return false;

		}
		ProductsEntity cartEntitt = (ProductsEntity) obj;
		return cartEntitt.getProductId() == this.getProductId() && cartEntitt.getPrice() == this.getPrice()
				&& cartEntitt.getSeller() == this.getSeller()
				&& cartEntitt.getProductName() == this.getProductName();
	}	

	
}
