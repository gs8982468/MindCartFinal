package com.MindCart.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.ProductInCartEntity;
import com.MindCart.EntityClass.ProductsEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.CartRepository;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UserProductRepo;
import com.MindCart.Repository.UsersRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DBManagementService {

	@Autowired
	private UsersRepository userRepo;

	@Autowired
	private CartRepository cartRepo;

	@Autowired
	private ProductListRepository prodListRepo;

	@Autowired
	private UserProductRepo userProdRepo;

	public UsersEntity findUserByUserId(long userId) {
		return userRepo.findUserRByUserId(userId);
	}

	public UsersEntity findUserByUserName(String userName) {
		return userRepo.findUserByUserName(userName);

	}

	public CartEntity findCartByUserId(long userId) {
		return cartRepo.findCartByUserId(userId);
	}

	public Optional<ProductsEntity> findProductDetailsByProductId(long productId) {
		return prodListRepo.findById(productId);
	}

	public List<ProductsEntity> findAllProducts() {
		return prodListRepo.findAll();
	}

	public List<ProductInCartEntity> findAllProductOfUsers(long cartId) {
		return userProdRepo.findAllProductOfUser(cartId);
	}

	public List<ProductInCartEntity> findUsersProduct() {
		return userProdRepo.findAll();
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateCartEntity(CartEntity cartEntity) {
		cartRepo.save(cartEntity);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteProductFromUserCart(long cartId, long productId) {
		userProdRepo.deleteProductFromUserCart(cartId, productId);
		;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateProductInUserCart(List<ProductInCartEntity> cartProductEntity) {
		userProdRepo.saveAll(cartProductEntity);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateUserDetails(UsersEntity userEntity) {
		userRepo.save(userEntity);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateAllProductsToDB(List<ProductsEntity> prodListEntity) {
		prodListRepo.saveAll(prodListEntity);
	}

}
