package com.MindCart.EntityClass;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CART")
//@NamedQuery(name = "UsersEntity.findAll", query="select user from UsersEntity user")
public class CartEntity {
	

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name = "CART_ID")
	private long cartId;
	
	@Column(name = "PRODUCT_ID")
	private long productId;
	
	
	@OneToOne
	@JoinColumn(name= "USER_ID")
	private UsersEntity user;
	
	//@OneToMany(mappedBy="cart")
	@OneToMany(cascade={CascadeType.PERSIST, CascadeType.MERGE},mappedBy="cart", fetch=FetchType.LAZY)
	private List<ProductInCartEntity> userProductEntity;
	

	

	public List<ProductInCartEntity> getUserProductEntity() {
		return userProductEntity;
	}

	public void setUserProductEntity(List<ProductInCartEntity> userProductEntity) {
		this.userProductEntity = userProductEntity;
	}

	public UsersEntity getUser() {
		return user;
	}

	public void setUser(UsersEntity user) {
		this.user = user;
	}

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!(obj instanceof CartEntity)) {
			return false;

		}
		CartEntity cartEntitt = (CartEntity) obj;
		return cartEntitt.getCartId() == this.getCartId() && cartEntitt.getProductId() == this.getProductId()
				&& cartEntitt.getUser() == this.getUser()
				&& cartEntitt.getUserProductEntity() == this.getUserProductEntity();
	}	


	 

}
