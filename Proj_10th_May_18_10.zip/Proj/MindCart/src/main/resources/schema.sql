create table USERS(
USER_ID number primary key,
USER_NAME varchar2(500) UNIQUE,
USER_FULL_NAME varchar2(500),
PASSWORD varchar2(500),
AGE number
);

insert into USERS values(101, 'admin', 'Subhankar Guchhait', 'admin', 25);


create table CART(
CART_ID number(500) primary key,
PRODUCT_ID number(500),
USER_ID number(500),
CONSTRAINT FK_USERID FOREIGN KEY(USER_ID) REFERENCES USERS(USER_ID)
);

create table CART_PRODUCT(
PRODUCT_ID number(500) primary key,
PRODUCT_NAME varchar2(500),
CART_ID number(500),
NO_OF_PRODUCT_ADDED varchar2(500),
PRICE number(500),
PRICE_TO_BE_PAID number,
CONSTRAINT FK_CARTID FOREIGN KEY(CART_ID) REFERENCES CART(CART_ID)
);

create table ALL_PRODUCT_LIST(
PRODUCT_ID number primary key,
PRODUCT_NAME varchar2(500),
SELLER varchar2(500), 
PRICE number
);

insert into ALL_PRODUCT_LIST values(501, 'MI MOBILE', 'ABC Company', 10000);
insert into ALL_PRODUCT_LIST values(502, 'SAMSUNG MOBILE', 'MNO Company', 9999);
insert into ALL_PRODUCT_LIST values(503, 'HONOR MOBILE', 'PQR Company', 12999);
insert into ALL_PRODUCT_LIST values(504, 'REALME MOBILE', 'XYZ Company',11349);