package com.MindCart.EntityClass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CART_PRODUCT")
//@NamedQuery(name = "UsersEntity.findAll", query="select user from UsersEntity user")
public class CartProductEntity {
	

	@Id
//	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name = "PRODUCT_ID")
	private long productId;
	
	@Column(name = "PRODUCT_NAME")
	private String productName;
	
	@Column(name = "NO_OF_PRODUCT_ADDED")
	private int productCount;
	
	@Column(name = "PRICE")
	private int price;
	
	
	@Column(name = "PRICE_TO_BE_PAID")
	private int priceToBePaid;
	
	public int getPriceToBePaid() {
		return priceToBePaid;
	}

	public void setPriceToBePaid(int priceToBePaid) {
		this.priceToBePaid = priceToBePaid;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	@ManyToOne
	@JoinColumn(name= "CART_ID")
	private CartEntity cart;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}


	public CartEntity getCart() {
		return cart;
	}

	public void setCart(CartEntity cart) {
		this.cart = cart;
	}

	
}
