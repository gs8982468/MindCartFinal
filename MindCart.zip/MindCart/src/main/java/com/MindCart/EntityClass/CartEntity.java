package com.MindCart.EntityClass;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CART")
//@NamedQuery(name = "UsersEntity.findAll", query="select user from UsersEntity user")
public class CartEntity {
	

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name = "CART_ID")
	private long cartId;
	
	@Column(name = "PRODUCT_ID")
	private long productId;
	
	
	@OneToOne
	@JoinColumn(name= "USER_ID")
	private UsersEntity user;
	
	@OneToMany(mappedBy="cart")
	private List<CartProductEntity> userProductEntity;
	

	

	public List<CartProductEntity> getUserProductEntity() {
		return userProductEntity;
	}

	public void setUserProductEntity(List<CartProductEntity> userProductEntity) {
		this.userProductEntity = userProductEntity;
	}

	public UsersEntity getUser() {
		return user;
	}

	public void setUser(UsersEntity user) {
		this.user = user;
	}

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}
	
	
	

	 

}
