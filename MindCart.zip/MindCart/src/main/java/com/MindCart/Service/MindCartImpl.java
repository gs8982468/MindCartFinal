package com.MindCart.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;

import com.MindCart.EntityClass.BookListEntity;
import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.CartProductEntity;
import com.MindCart.EntityClass.ProductListEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.CartRepository;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UserProductRepo;
import com.MindCart.Repository.UsersRepository;

@Component
public class MindCartImpl implements MindCartIF {

	@Autowired
	private UsersRepository userRepo;

	@Autowired
	private CartRepository cartRepo;

	@Autowired
	private ProductListRepository prodListRepo;

	@Autowired
	private UserProductRepo userProdRepo;

	@Override
	public void mindcartHomePage(Model model) {
		List<UsersEntity> users = addUserToDBToTestFunctionality();
		setProductetailsToBeAddedIntoCart();
		model.addAttribute("users", users);
	}

	@Override
	public void fetchUserDataFromDB(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		modelMap.put("userFullName", ueserEntity.getUserFullName());
		modelMap.put("userid", ueserEntity.getUserId());
		// model.addAttribute("userid", ueserEntity.getUserId());
		model.addAttribute("ue", ueserEntity);

	}

	@Override
	public String addProductToCart(Model model, ModelMap modelMap, long userId, long productId) {
		String urlS = redirectToProdList(userId);

		Optional<ProductListEntity> findProduct = prodListRepo.findById(productId);
		ProductListEntity productListEntity = (findProduct.isPresent()) ? findProduct.get() : null;
		List<CartProductEntity> cartProductEntity = new ArrayList<>();
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		if (null != ueserEntity) {
			CartEntity cartEntity = cartRepo.findCartByUserId(userId);
			cartProductEntity = null != userProdRepo.findAll() ? userProdRepo.findAll() : new ArrayList<>();
			if (null == cartEntity) {
				cartEntity = new CartEntity();
			} else {
				cartProductEntity = userProdRepo.findAllProductOfUser(cartEntity.getCartId());
			}

			Optional<CartProductEntity> cartProdEntityOptional = cartProductEntity.stream()
					.filter(upe -> (productId == upe.getCart().getProductId())).findFirst();
			if (cartProdEntityOptional.isPresent() && null != cartProdEntityOptional.get()) {
				modelMap.put("presentInCart", "This Product alreay present in your cart");
				return "redirect:" + urlS;

			} else {

				CartProductEntity cartProdEntity = new CartProductEntity();
				cartProdEntity.setProductId((null != productListEntity) ? productListEntity.getProductId(): null);
				cartProdEntity.setProductName((null!= productListEntity)? productListEntity.getProductName(): null);
				cartProdEntity.setPrice((null!= productListEntity)? productListEntity.getPrice(): 0);
				cartProdEntity.setPriceToBePaid((null!= productListEntity)? productListEntity.getPrice(): 0);
				cartProdEntity.setProductCount(1);
				cartProdEntity.setCart(cartEntity);
				cartProductEntity.add(cartProdEntity);

				cartEntity.setUser(ueserEntity);

				cartRepo.save(cartEntity);
				userProdRepo.saveAll(cartProductEntity);
				modelMap.put("prodAddedToCart", "Product added into your cart");
				// return "redirect:/mindcart/productList";
				return "redirect:" + urlS;
			}

		}

		return "redirect:" + urlS;

	}

	private String redirectToProdList(long userId) {
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/");
		url.append(userId);
		url.append("/productList");
		String urlS = url.toString();
		return urlS;
	}
	
	@Override
	public String removeAllProduct(Model model, ModelMap modelMap, long userId) {
		
		
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		List<Long> listOfProductIdToBeDeleted = new ArrayList<>();
		if (null != cartEntity) {

			long us = cartEntity.getCartId();
			List<CartProductEntity> cartProdEntity = null != cartEntity.getUserProductEntity()
					? cartEntity.getUserProductEntity() : null;
					
			for(CartProductEntity cpe: cartProdEntity){
				listOfProductIdToBeDeleted.add(cpe.getProductId());
				//removeProductFromCart(model, modelMap, userId, cpe.getProductId(), cartProdEntity, cpe);
			}
		}
		
		userProdRepo.deleteAllById(listOfProductIdToBeDeleted);
		UsersEntity ueserEntityUpdated = userRepo.findUserRByUserId(userId);
		CartEntity cartEntityUpdated = ueserEntityUpdated.getCartEntity();
		if (null!= cartEntityUpdated) {
			
			List<CartProductEntity> cartProdEntityUpdated = null!= cartEntityUpdated.getUserProductEntity()? cartEntityUpdated.getUserProductEntity():null;
			//upe.get(0).get
			if (!CollectionUtils.isEmpty(cartProdEntityUpdated)) {
				model.addAttribute("upe", cartProdEntityUpdated);
				modelMap.put("userid", userId);
				//return "USER_CART";
			} 
		}
		
		String urlS = redirectToProdList(userId);

		return "redirect:" + urlS;
	}

	@Override
	public String fetchCartDetails(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		if (null!= cartEntity) {
			
			long us = cartEntity.getCartId();
			List<CartProductEntity> cartProdEntity = null!= cartEntity.getUserProductEntity()? cartEntity.getUserProductEntity():null;
			//upe.get(0).get
			if (!CollectionUtils.isEmpty(cartProdEntity)) {
				model.addAttribute("upe", cartProdEntity);
				modelMap.put("userid", userId);
				return "USER_CART";
			} 
		}
		String urlS = redirectToProdList(userId);
		modelMap.put("noProd", "No product availabale");
		return "redirect:" + urlS;
	}

	@Override
	public String increaseItem(Model model, ModelMap modelMap, long userId, long productId) {
		CartEntity cartEntity = cartRepo.findCartByUserId(userId);
		List<CartProductEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<CartProductEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				currentCount = currentCount + 1;
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				userProdRepo.save(userProdOptional.get());
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String urlS = url.toString();

		return "redirect:" + urlS;
	}

	@Override
	public String decreaseItem(Model model, ModelMap modelMap, long userId, long productId) {
		CartEntity cartEntity = cartRepo.findCartByUserId(userId);
		List<CartProductEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<CartProductEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				if (currentCount > 1) {
					currentCount = currentCount - 1;
				} else if (currentCount == 1) {
					removeProductFromCart(model, modelMap, userId, productId, userProd, userProdOptional.get());
					return fetchCartDetails(model, modelMap, userId);
				}
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				userProdRepo.save(userProdOptional.get());
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String urlS = url.toString();

		return "redirect:" + urlS;
	}

	private void removeProductFromCart(Model model, ModelMap modelMap, long userId, long productId,
			List<CartProductEntity> cartProdEntityList, CartProductEntity cartProdEntity) {
		cartProdEntityList.remove(cartProdEntity);
		userProdRepo.deleteById(productId);
		//return fetchCartDetails(model, modelMap, userId);
	}
	
	
	private List<UsersEntity> addUserToDBToTestFunctionality() {
		List<UsersEntity> users = new ArrayList<>();
		UsersEntity user = addUsersToDBToTestFunctionality("admin", "admin", "Subhankar Guchhait", 25);
		UsersEntity user1 = addUsersToDBToTestFunctionality("rupsha", "rupsha", "Rupsha Mukhuty", 26);
		UsersEntity user2 = addUsersToDBToTestFunctionality("Vaskar", "vaskar", "Vaskar Guchhait", 21);
		users.add(user);
		users.add(user1);
		users.add(user2);
		return users;
	}
	
	private UsersEntity addUsersToDBToTestFunctionality(String userName, String password, String fullName, int age) {
		UsersEntity us = new UsersEntity();
		us.setUserName(userName);
		us.setPassword(password);
		us.setUserFullName(fullName);
		us.setAge(age);
		userRepo.save(us);
		return us;
	}
	
	private void setProductetailsToBeAddedIntoCart() {
		List<ProductListEntity> prodListEntity = new ArrayList<>();
		prodListEntity.add(addProductIntoDB(501, "REDMI NOTE 10 PRO", "SANDHYA TELECOM", 16999));
		prodListEntity.add(addProductIntoDB(601, "REDMI NOTE 9 PRO", "SANDHYA TELECOM", 10999));
		prodListEntity.add(addProductIntoDB(701, "CHaya prakashani Math Book", "Jaggeswar Book Srtore", 500));
		prodListEntity.add(addProductIntoDB(801, "CHaya prakashani Physics Book", "Jaggeswar Book Srtore", 600));
		prodListEntity.add(addProductIntoDB(901, "Realme 2 PRO", "SANDHYA TELECOM", 12599));

		prodListRepo.saveAll(prodListEntity);
	}
	
	private ProductListEntity addProductIntoDB(long productId, String productName, String sellerName, int price){
		ProductListEntity prodEntity = new ProductListEntity();
		prodEntity.setProductId(productId);
		prodEntity.setProductName(productName);
		prodEntity.setSeller(sellerName);
		prodEntity.setPrice(price);
		return prodEntity;
	}
	
	
	//below method is getting used for this application
	
	@Override
	public String login(ModelMap modelMap, String userName, String password, Model model) {

		String redirectTo = "login";
		UsersEntity user = userRepo.findUserR(userName);
		if (user != null) {
			List<ProductListEntity> prodList = prodListRepo.findAll();

			if (null != prodList) {
				model.addAttribute("prodList", prodList);
			}
			redirectTo = populateUserDetails(modelMap, userName, password, user);
		} else {
			modelMap.put("userNotExist", "User doesn't exist");
		}
		return redirectTo;

	}
	
	//below method is getting used for this application
	private String populateUserDetails(ModelMap model, String userName, String password, UsersEntity user) {
		String redirectTo = "login";
		if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
			CartEntity ce = (null != user.getCartEntity()) ? user.getCartEntity() : null;
			if (null != ce) {
				model.put("productId", ce.getProductId());
				// model.put("productCount", ce.getProductCount());
			}

			model.put("userName", user.getUserFullName());
			redirectTo = "Welcome";
		} else {
			model.put("loginError", "Please enter the correct password");
		}
		return redirectTo;
	}




}
