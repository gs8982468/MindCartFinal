package com.MindCart.Service;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

@Component
public interface MindCartIF {

	void mindcartHomePage(Model model);
	
	String login(ModelMap modelMap,String username, String password, Model model);
	
	void fetchUserDataFromDB(Model model, ModelMap modelMap, long userId);

	String addProductToCart(Model model, ModelMap modelMap, long userId, long productId);

	String fetchCartDetails(Model model, ModelMap modelMap, long userId);

	String increaseItem(Model model, ModelMap modelMap, long userId, long productId);

	String decreaseItem(Model model, ModelMap modelMap, long userId, long productId);

	String removeAllProduct(Model model, ModelMap modelMap, long userId);
	
	
	
	
	
}
