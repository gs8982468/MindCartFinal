package com.MindCart.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.MindCart.EntityClass.ProductListEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Pojo.Users;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UsersRepository;
import com.MindCart.Service.MindCartIF;

@Controller
@RequestMapping("/mindcart")
public class MindCartController {
	
	@Autowired
	private UsersRepository ur;
	
	
	@Autowired
	private ProductListRepository productListRepo;
	
	@Autowired
	private MindCartIF mindCartIf;
	
	/**
	 * This method is used for redirecting to the home page of this CART application
	 * 
	 * @param model of Model type
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/home", method= RequestMethod.GET)
	public String redirectHomePage(Model model){
		mindCartIf.mindcartHomePage(model);
		
		return "Mindcart_Portal";
		
	}
	
	/**
	 * This method is to find user details from DB and help us to proceed with that user for testing this CART application project
	 * @param model of type Model, used to send data to UI model to show the data in the screen
	 * @param modelMap of type ModelType to send data to UI model to show the data in the screen
	 * @param userId of type Long used to find data from DB
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/home/{userId}", method= RequestMethod.GET)
	public String fetchUserDetailsAndProceedWithThatUser(Model model, ModelMap modelMap, @PathVariable long userId){
		
		mindCartIf.fetchUserDataFromDB(model, modelMap, userId);
		return("Welcome");
	}
	
	/**
	 * This method is used to add the product into cart.
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @param productId of type Long
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/product/addToCart/{userId}/{productId}", method= RequestMethod.GET)
	public String addToCart(Model model, ModelMap modelMap, @PathVariable long userId, @PathVariable long productId){
		
		//mindCartIf.fetchUserDataFromDB(model, modelMap, userId);
		// write logic to add product details into cart
		
		String redirectedUrl = mindCartIf.addProductToCart(model, modelMap, userId, productId);
		
		StringBuilder url= new StringBuilder("http://localhost:9104/mindcart/home/");
		url.append(userId);
		String urlS= url.toString();
	//	model.addAllAttributes(users);
		return redirectedUrl;
	}
	
	/**
	 * This method is used to add the product into cart.
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @param productId of type Long
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/product/remove/{userId}", method= RequestMethod.GET)
	public String removeAllProducts(Model model, ModelMap modelMap, @PathVariable long userId){
		
		//mindCartIf.fetchUserDataFromDB(model, modelMap, userId);
		// write logic to add product details into cart
		
		String redirectedUrl = mindCartIf.removeAllProduct(model, modelMap, userId);
		
		StringBuilder url= new StringBuilder("http://localhost:9104/mindcart/home/");
		url.append(userId);
		String urlS= url.toString();
	//	model.addAllAttributes(users);
		return redirectedUrl;
	}
	
	
	/**
	 * This method is used to view all types of product in the product tab. User can add the product into their CART using addToCart button if want.
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="{userId}/productList", method= RequestMethod.GET)
	public String getProducts(Model model, ModelMap modelmap, @PathVariable long userId){
		List<ProductListEntity> pl = productListRepo.findAll();
		
		model.addAttribute("products",pl);
		
		UsersEntity ue = ur.findUserRByUserId(userId);
		modelmap.put("userFullName", ue.getUserFullName());
		modelmap.put("userid", ue.getUserId());
		return "products";
	}
	
	/**
	 * This method is used to fetch the CART data of any users
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/cart/{userId}", method= RequestMethod.GET)
	public String fetchCart(Model model, ModelMap modelMap, @PathVariable long userId){
		
		String redirectedUrl = mindCartIf.fetchCartDetails(model, modelMap, userId);
		
		return redirectedUrl;
	}
	
	/**
	 * This method is used to increase the number of a added product into the cart.
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @param productId of type Long
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/product/increaseItem/{userId}/{productId}", method= RequestMethod.GET)
	public String increaseItem(Model model, ModelMap modelMap, @PathVariable long userId, @PathVariable long productId){
		String redirectedUrl = mindCartIf.increaseItem(model, modelMap, userId, productId);
		return redirectedUrl;
	}
	
	/**
	 * This method is used to increase the number of a added product into the cart.
	 * @param model of type Model, used to send data to the UI 
	 * @param modelMap of type ModelMap, used to send data to the UI 
	 * @param userId of type Long used to fetch user details and cart details of the corresponding user from DB
	 * @param productId of type Long
	 * @return String type used to redirect the JSP page
	 */
	@RequestMapping(value="/product/decreaseItem/{userId}/{productId}", method= RequestMethod.GET)
	public String decreaseItem(Model model, ModelMap modelMap, @PathVariable long userId, @PathVariable long productId){
		String redirectedUrl = mindCartIf.decreaseItem(model, modelMap, userId, productId);
		return redirectedUrl;
	}
	
	
	//=====================================================================================

	
	
	
	//Below Method is not getting used into this CART application
	
	
	@RequestMapping(value="/reg", method= RequestMethod.GET)
	public String reg(){
			return "registration";
		
	}
	

	//Below Method is not getting used into this CART application
	
	@RequestMapping(value="/registration", method= RequestMethod.POST)
	public String signUp(ModelMap modelMap,  @RequestParam String userName,  @RequestParam String userFullName, @RequestParam String password,  @RequestParam int age){
		UsersEntity user = ur.findUserR(userName);
		if(user != null){
			modelMap.put("UserExist", "user already exist");
		}else{
			user = new UsersEntity();
			//user.setUserId(userId);
			user.setUserName(userName);
			user.setUserFullName(userFullName);
			user.setPassword(password);
			user.setAge(age);
			ur.save(user);
			modelMap.put("regSuccessful", "Registration Successful");
		}
		
		
		return "registration";
		
	}
	
	//Below Method is not getting used into this CART application
	
	@RequestMapping(value="/log", method= RequestMethod.POST)
	public String welcome(ModelMap modelMap, @RequestParam String userName, @RequestParam String password, Model model){
		String redirectTo= mindCartIf.login(modelMap, userName, password, model);
		
		return redirectTo;
	}
	
	@RequestMapping(value="/log", method= RequestMethod.GET)
	public String welcome1(ModelMap model, @RequestParam String userName, @RequestParam String password){
		
		
		return "welcome";
	}

	
	/*@RequestMapping(value="/productList", method= RequestMethod.GET)
	public ModelAndView getProducts(Model model){
		ModelAndView mv = new ModelAndView();
		
		
		
		List<Users> users = new ArrayList<>();
		Users user= new Users();
		user.setAge(20);
		user.setName("Subhankar");
		
		Users user1= new Users();
		user1.setAge(25);
		user1.setName("Rupsha");
		
		users.add(user1);
		users.add(user);
		model.addAttribute(users);
		mv.setViewName("products");
		//model.addAllAttributes(users);
		mv.addObject("users",users);
		return mv;
	}
*/	
}
