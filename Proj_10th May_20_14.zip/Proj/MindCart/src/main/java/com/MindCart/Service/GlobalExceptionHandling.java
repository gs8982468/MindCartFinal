package com.MindCart.Service;

import java.sql.SQLException;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class GlobalExceptionHandling {
	
	@ExceptionHandler(NullPointerException.class)
	public String nullPointerExceptionHandler(){
		return "Null pointer Exception occurred";
	}
	
	@ExceptionHandler(ArrayIndexOutOfBoundsException.class)
	public String arrayIndexOutOfBoundException(){
		return "Array index out of bound  Exception occurred";
	}
	
	
	@ExceptionHandler(SQLException.class)
	public String sqlExceptionHandler(){
		return "SQL Exception occurred";
	}
}
