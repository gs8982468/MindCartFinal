package com.MindCart.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;

import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.ProductInUserCartEntity;
import com.MindCart.EntityClass.GlobalProductEntity;
import com.MindCart.EntityClass.UsersEntity;

@Service
public class MindCartImpl implements MindCartIF {
	
	@Autowired
	private DBManagementServiceIF dbManager;
	
	private static final Logger log = LoggerFactory.getLogger(MindCartImpl.class);

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#retrieveMindCartHomePage(org.springframework.ui.Model)
	 */
	@Override
	public void retrieveMindCartHomePage(Model model) {
		List<UsersEntity> users = addDefaultUserToDB();
		addProductsIntoProductPage();
		model.addAttribute("users", users);
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#fetchUserDataFromDB(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	public void fetchUserDataFromDB(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity;
		try {

			ueserEntity = dbManager.findUserByUserId(userId);
		} catch (Exception e) {
			log.info("problem occurred while fetching user details from DB");
			throw new ServiceException("Something went wrong... please try again later");
		}
		modelMap.put("userFullName", ueserEntity.getUserFullName());
		modelMap.put("userid", ueserEntity.getUserId());
		model.addAttribute("ue", ueserEntity);
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#addProductToCart(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	@Transactional
	public String addProductToCart(Model model, ModelMap modelMap, long userId, long productId) throws Exception{
		String redirectingURL = redirectToProdList(userId);

		Optional<GlobalProductEntity> findProductByProductId = dbManager.findProductDetailsByProductId(productId);
		GlobalProductEntity globalProductListEntity = (findProductByProductId.isPresent()) ? findProductByProductId.get() : null;
		List<ProductInUserCartEntity> productInUserCart = new ArrayList<>();
		UsersEntity ueserEntity = dbManager.findUserByUserId(userId);
		
		if (null != ueserEntity) {
			CartEntity userCartEntity = dbManager.findCartByUserId(userId);
			productInUserCart = null != dbManager.findUsersProduct() ? dbManager.findUsersProduct() : new ArrayList<>();
			if (null == userCartEntity) {
				userCartEntity = new CartEntity();
			} else {
				productInUserCart = dbManager.findAllProductOfUsers(userCartEntity.getCartId());
			}

			Optional<ProductInUserCartEntity> cartProdEntityOptional = productInUserCart.stream()
					.filter(cpe -> (productId == cpe.getProductId())).findFirst();
			return checkAndSaveProductIntoUserCart(model, modelMap, userId, globalProductListEntity, productInUserCart,
					ueserEntity, userCartEntity, cartProdEntityOptional);

		}

		return "redirect:" + redirectingURL;

	}

	private String checkAndSaveProductIntoUserCart(Model model, ModelMap modelMap, long userId,
			GlobalProductEntity productListEntity, List<ProductInUserCartEntity> productInUserCart, UsersEntity ueserEntity,
			CartEntity userCartEntity, Optional<ProductInUserCartEntity> cartProdEntityOptional) throws Exception{
		if (cartProdEntityOptional.isPresent() && null != cartProdEntityOptional.get()) {
			modelMap.put("presentInCart", cartProdEntityOptional.get().getProductName()+" : this Product is alreay present in your cart");
			fetchProductList(model, modelMap, userId);
			return "products";

		} else {

			return saveProductsIntoUserCart(model, modelMap, userId, productListEntity, productInUserCart,
					ueserEntity, userCartEntity);
		}
	}

	private String saveProductsIntoUserCart(Model model, ModelMap modelMap, long userId,
			GlobalProductEntity globalProductListEntity, List<ProductInUserCartEntity> cartProductEntity, UsersEntity ueserEntity,
			CartEntity cartEntity) throws Exception{
		ProductInUserCartEntity cartProdEntity = new ProductInUserCartEntity();
		cartProdEntity.setProductId((null != globalProductListEntity) ? globalProductListEntity.getProductId(): null);
		cartProdEntity.setProductName((null!= globalProductListEntity)? globalProductListEntity.getProductName(): null);
		cartProdEntity.setPrice((null!= globalProductListEntity)? globalProductListEntity.getPrice(): 0);
		cartProdEntity.setPriceToBePaid((null!= globalProductListEntity)? globalProductListEntity.getPrice(): 0);
		cartProdEntity.setProductCount(1);
		cartProdEntity.setCart(cartEntity);
		cartProductEntity.add(cartProdEntity);

		cartEntity.setUser(ueserEntity);

		try {
			dbManager.updateCartEntity(cartEntity);
			dbManager.updateProductsInUserCart(cartProductEntity);
		} catch (Exception e) {
			log.info("Error occurred while saving the data to DB");
			throw new ServiceException("Some Problem occurred.. Please try again");
		}
		modelMap.put("prodAddedToCart", globalProductListEntity.getProductName()+"  is added into your cart");
		fetchProductList(model, modelMap, userId);
		return "products";
	}

	private void fetchProductList(Model model, ModelMap modelMap, long userId) {
		List<GlobalProductEntity> findAllGlobalProductList = dbManager.findAllGlobalProducts();
		
		model.addAttribute("products",findAllGlobalProductList);
		UsersEntity ueserEntity = dbManager.findUserByUserId(userId);
		modelMap.put("userFullName", ueserEntity.getUserFullName());
		modelMap.put("userid", ueserEntity.getUserId());
	}

	private String redirectToProdList(long userId) {
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/");
		url.append(userId);
		url.append("/productList");
		String redirectingURL = url.toString();
		return redirectingURL;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#removeAllProduct(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	@Transactional
	public String removeUserCartsProducts(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = dbManager.findUserByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		
		if (null != cartEntity) {
			List<ProductInUserCartEntity> cartProdEntity = null != cartEntity.getUserProductEntity()
					? cartEntity.getUserProductEntity() : null;

			Iterator<ProductInUserCartEntity> cartProdTOBeDeleted = cartProdEntity.iterator();
			while(cartProdTOBeDeleted.hasNext()){
				try {
					dbManager.deleteProductFromUserCart(cartEntity.getCartId(), cartProdTOBeDeleted.next().getProductId());
				} catch (Exception e) {
					log.info("Error occurred while deleting the product from User cart");
					throw new ServiceException("Something went wrong. Please try again");
				}
			}
		}
		modelMap.put("productsRemoved", "All products from your cart removed. please add products to your cart again");
		fetchProductList(model, modelMap, userId);
		return "products";

	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#fetchCartDetails(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	@Transactional
	public String fetchUserCartDetails(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = dbManager.findUserByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		if (null!= cartEntity) {
			
			List<ProductInUserCartEntity> cartProdEntity = null!= cartEntity.getUserProductEntity()? cartEntity.getUserProductEntity():null;

			if (!CollectionUtils.isEmpty(cartProdEntity)) {
				fetchProductList(model, modelMap, userId);
				model.addAttribute("upe", cartProdEntity);
				modelMap.put("userid", userId);
				return "USER_CART";
			} 
			else{
				modelMap.put("noProd", "No product availabale in your cart, please add products in your cart and then proceed");
				fetchProductList(model, modelMap, userId);
				return "products";
			}
		}
		
		modelMap.put("noProd", "No product availabale in your cart,  please add products in your cart and then proceed");
		fetchProductList(model, modelMap, userId);
		return "products";
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#increaseItem(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	@Transactional
	public String increaseCartItemsQuantity(Model model, ModelMap modelMap, long userId, long productId) throws Exception, RuntimeException{
		CartEntity cartEntity = dbManager.findCartByUserId(userId);
		List<ProductInUserCartEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<ProductInUserCartEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				currentCount = currentCount + 1;
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				try {
					dbManager.updateProductInUserCart(userProdOptional.get());
				} catch (Exception e) {
					log.info("Error occurred while updating the product into User cart");
					throw new ServiceException("Something went wrong. Please try again");
				}
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String urlS = url.toString();

		return "redirect:" + urlS;
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#decreaseItem(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	@Transactional
	public String decreaseCartItemsQuantity(Model model, ModelMap modelMap, long userId, long productId) throws Exception{
		CartEntity cartEntity = dbManager.findCartByUserId(userId);
		List<ProductInUserCartEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<ProductInUserCartEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				if (currentCount > 1) {
					currentCount = currentCount - 1;
				} else if (currentCount == 1) {
					removeProductFromCart(model, modelMap, userId, productId, userProd, userProdOptional.get());
					return fetchUserCartDetails(model, modelMap, userId);
				}
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				try {
					dbManager.updateProductInUserCart(userProdOptional.get());
				} catch (Exception e) {
					log.info("Error occurred while updating the product into User cart");
					throw new ServiceException("Something went wrong. Please try again");
				}
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String redirectingURL = url.toString();

		return "redirect:" + redirectingURL;
	}

	private void removeProductFromCart(Model model, ModelMap modelMap, long userId, long productId,
			List<ProductInUserCartEntity> cartProdEntityList, ProductInUserCartEntity cartProdEntity) {
		cartProdEntityList.remove(cartProdEntity);
		try {
			dbManager.deleteByProductIdFromUserCart(productId);
		} catch (Exception e) {
			log.info("Error occurred while deleting the product from User cart");
			throw new ServiceException("Something went wrong. Please try again");
		}
	}
	
	/**
	 * This method is used to add few default user into DB for testing all the functionality
	 * @return UsersEntity
	 */
	private List<UsersEntity> addDefaultUserToDB() {
		List<UsersEntity> users = new ArrayList<>();
		UsersEntity user = addUsersToDBToTestFunctionality("admin", "admin", "Subhankar Guchhait", 25);
		UsersEntity user1 = addUsersToDBToTestFunctionality("rupsha", "rupsha", "Rupsha Mukhuty", 26);
		UsersEntity user2 = addUsersToDBToTestFunctionality("Vaskar", "vaskar", "Vaskar Guchhait", 21);
		users.add(user);
		users.add(user1);
		users.add(user2);
		return users;
	}
	
	private UsersEntity addUsersToDBToTestFunctionality(String userName, String password, String fullName, int age) {
		UsersEntity userEntity = new UsersEntity();
		userEntity.setUserName(userName);
		userEntity.setPassword(password);
		userEntity.setUserFullName(fullName);
		userEntity.setAge(age);
		try {
			dbManager.updateUserDetails(userEntity);
		} catch (Exception e) {
			log.info("Error occurred while updating the user details");
			throw new ServiceException("Something went wrong. Please try again");
		}
		return userEntity;
	}
	
	/**
	 * This method is used to add few products into the product list and user can add these product into their cart
	 */
	private void addProductsIntoProductPage() {
		List<GlobalProductEntity> globalProductList = new ArrayList<>();
		globalProductList.add(addProductIntoDB(501, "REDMI NOTE 10 PRO", "SANDHYA TELECOM", 16999));
		globalProductList.add(addProductIntoDB(601, "REDMI NOTE 9 PRO", "SANDHYA TELECOM", 10999));
		globalProductList.add(addProductIntoDB(701, "CHaya prakashani Math Book", "Jaggeswar Book Srtore", 500));
		globalProductList.add(addProductIntoDB(801, "CHaya prakashani Physics Book", "Jaggeswar Book Srtore", 600));
		globalProductList.add(addProductIntoDB(901, "Realme 2 PRO", "SANDHYA TELECOM", 12599));
		dbManager.updateGlobalProductListToDB(globalProductList);
	}
	
	private GlobalProductEntity addProductIntoDB(long productId, String productName, String sellerName, int price){
		GlobalProductEntity globalProdEntity = new GlobalProductEntity();
		globalProdEntity.setProductId(productId);
		globalProdEntity.setProductName(productName);
		globalProdEntity.setSeller(sellerName);
		globalProdEntity.setPrice(price);
		return globalProdEntity;
	}
	
	
	//below method is getting used for this application
	
	@Override
	public String login(ModelMap modelMap, String userName, String password, Model model) {

		String redirectTo = "login";
		UsersEntity user = dbManager.findUserByUserName(userName);
		if (user != null) {
			List<GlobalProductEntity> allGlobalProdList = dbManager.findAllGlobalProducts();

			if (null != allGlobalProdList) {
				model.addAttribute("prodList", allGlobalProdList);
			}
			redirectTo = populateUserDetails(modelMap, userName, password, user);
		} else {
			modelMap.put("userNotExist", "User doesn't exist");
		}
		return redirectTo;

	}
	
	//below method is getting used for this application
	private String populateUserDetails(ModelMap model, String userName, String password, UsersEntity user) {
		String redirectTo = "login";
		if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
			CartEntity ce = (null != user.getCartEntity()) ? user.getCartEntity() : null;
			if (null != ce) {
				model.put("productId", ce.getProductId());
			}

			model.put("userName", user.getUserFullName());
			redirectTo = "Welcome";
		} else {
			model.put("loginError", "Please enter the correct password");
		}
		return redirectTo;
	}




}
