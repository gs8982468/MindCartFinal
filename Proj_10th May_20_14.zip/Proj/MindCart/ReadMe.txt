Hi Reader,

This is a cart application.

This application is being created using below technology or framework-
1. Spring boot
2. Java
3. JPA
4. JSP
5. Maven
6. H2 In memory dataBase

To test the application please open the below url in your local system-

**********************
To access the portal:
**********************
http://localhost:9104/mindcart/home

here 9104 is the port number mentioned in the application.properties file.


********************************************************************************
Transactional applied in DBManagementService.java class
Casecade, fetchtype are applied in the entity classs...
********************************************************************************

**********************
For Database check :
**********************

URL : http://localhost:9104/h2
JDBC URL : jdbc:h2:mem:subho1