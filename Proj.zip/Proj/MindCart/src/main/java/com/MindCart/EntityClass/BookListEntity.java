package com.MindCart.EntityClass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BOOK")
//@NamedQuery(name = "UsersEntity.findAll", query="select user from UsersEntity user")
public class BookListEntity extends CartEntity{
	

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name = "BOOK_ID")
	private long productId;
	
	@Column(name = "PRODUCT_TYPE")
	private String typeOfProduct;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getTypeOfProduct() {
		return typeOfProduct;
	}

	public void setTypeOfProduct(String typeOfProduct) {
		this.typeOfProduct = typeOfProduct;
	}
	

	
}
