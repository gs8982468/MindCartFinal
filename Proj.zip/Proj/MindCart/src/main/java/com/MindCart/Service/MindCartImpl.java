package com.MindCart.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.MindCart.Controller.MindCartController;
import com.MindCart.EntityClass.BookListEntity;
import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.ProductInCartEntity;
import com.MindCart.EntityClass.ProductsEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.CartRepository;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UserProductRepo;
import com.MindCart.Repository.UsersRepository;

@Component
public class MindCartImpl implements MindCartIF {

	@Autowired
	private UsersRepository userRepo;

	@Autowired
	private CartRepository cartRepo;

	@Autowired
	private ProductListRepository prodListRepo;

	@Autowired
	private UserProductRepo userProdRepo;
	
	private static final Logger log = LoggerFactory.getLogger(MindCartImpl.class);

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#retrieveMindCartHomePage(org.springframework.ui.Model)
	 */
	@Override
	public void retrieveMindCartHomePage(Model model) {
		List<UsersEntity> users = addDefaultUserToDB();
		addProductsIntoProductPage();
		model.addAttribute("users", users);
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#fetchUserDataFromDB(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	public void fetchUserDataFromDB(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		modelMap.put("userFullName", ueserEntity.getUserFullName());
		modelMap.put("userid", ueserEntity.getUserId());
		model.addAttribute("ue", ueserEntity);
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#addProductToCart(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	public String addProductToCart(Model model, ModelMap modelMap, long userId, long productId) {
		String redirectingURL = redirectToProdList(userId);

		Optional<ProductsEntity> findProduct = prodListRepo.findById(productId);
		ProductsEntity productListEntity = (findProduct.isPresent()) ? findProduct.get() : null;
		List<ProductInCartEntity> productInUserCart = new ArrayList<>();
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		
		if (null != ueserEntity) {
			CartEntity userCartEntity = cartRepo.findCartByUserId(userId);
			productInUserCart = null != userProdRepo.findAll() ? userProdRepo.findAll() : new ArrayList<>();
			if (null == userCartEntity) {
				userCartEntity = new CartEntity();
			} else {
				productInUserCart = userProdRepo.findAllProductOfUser(userCartEntity.getCartId());
			}

			Optional<ProductInCartEntity> cartProdEntityOptional = productInUserCart.stream()
					.filter(cpe -> (productId == cpe.getProductId())).findFirst();
			return checkAndSaveProductIntoUserCart(model, modelMap, userId, productListEntity, productInUserCart,
					ueserEntity, userCartEntity, cartProdEntityOptional);

		}

		return "redirect:" + redirectingURL;

	}

	private String checkAndSaveProductIntoUserCart(Model model, ModelMap modelMap, long userId,
			ProductsEntity productListEntity, List<ProductInCartEntity> productInUserCart, UsersEntity ueserEntity,
			CartEntity userCartEntity, Optional<ProductInCartEntity> cartProdEntityOptional) {
		if (cartProdEntityOptional.isPresent() && null != cartProdEntityOptional.get()) {
			modelMap.put("presentInCart", cartProdEntityOptional.get().getProductName()+"This Product alreay present in your cart");
			fetchProductList(model, modelMap, userId);
			return "products";

		} else {

			return saveProductsIntoUserCart(model, modelMap, userId, productListEntity, productInUserCart,
					ueserEntity, userCartEntity);
		}
	}

	private String saveProductsIntoUserCart(Model model, ModelMap modelMap, long userId,
			ProductsEntity productListEntity, List<ProductInCartEntity> cartProductEntity, UsersEntity ueserEntity,
			CartEntity cartEntity) {
		ProductInCartEntity cartProdEntity = new ProductInCartEntity();
		cartProdEntity.setProductId((null != productListEntity) ? productListEntity.getProductId(): null);
		cartProdEntity.setProductName((null!= productListEntity)? productListEntity.getProductName(): null);
		cartProdEntity.setPrice((null!= productListEntity)? productListEntity.getPrice(): 0);
		cartProdEntity.setPriceToBePaid((null!= productListEntity)? productListEntity.getPrice(): 0);
		cartProdEntity.setProductCount(1);
		cartProdEntity.setCart(cartEntity);
		cartProductEntity.add(cartProdEntity);

		cartEntity.setUser(ueserEntity);

		try {
			cartRepo.save(cartEntity);
			userProdRepo.saveAll(cartProductEntity);
		} catch (Exception e) {
			
			log.info("Error occurred while saving the data to DB");
		}
		modelMap.put("prodAddedToCart", productListEntity.getProductName()+" added into your cart");
		fetchProductList(model, modelMap, userId);
		return "products";
	}

	private void fetchProductList(Model model, ModelMap modelMap, long userId) {
		List<ProductsEntity> pl = prodListRepo.findAll();
		
		model.addAttribute("products",pl);
		
		UsersEntity ue = userRepo.findUserRByUserId(userId);
		modelMap.put("userFullName", ue.getUserFullName());
		modelMap.put("userid", ue.getUserId());
	}

	private String redirectToProdList(long userId) {
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/");
		url.append(userId);
		url.append("/productList");
		String redirectingURL = url.toString();
		return redirectingURL;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#removeAllProduct(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	public String removeAllProduct(Model model, ModelMap modelMap, long userId) {

		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		List<Long> listOfProductIdToBeDeleted = new ArrayList<>();
		if (null != cartEntity) {

			long us = cartEntity.getCartId();
			List<ProductInCartEntity> cartProdEntity = null != cartEntity.getUserProductEntity()
					? cartEntity.getUserProductEntity() : null;

			for (ProductInCartEntity cpe : cartProdEntity) {
				listOfProductIdToBeDeleted.add(cpe.getProductId());
				// removeProductFromCart(model, modelMap, userId,
				// cpe.getProductId(), cartProdEntity, cpe);
			}
		}

		userProdRepo.deleteAllById(listOfProductIdToBeDeleted);
		UsersEntity ueserEntityUpdated = userRepo.findUserRByUserId(userId);
		
		
		/*CartEntity cartEntityUpdated = ueserEntityUpdated.getCartEntity();
		if (null != cartEntityUpdated) {

			List<CartProductEntity> cartProdEntityUpdated = null != cartEntityUpdated.getUserProductEntity()
					? cartEntityUpdated.getUserProductEntity() : null;
			// upe.get(0).get
			if (!CollectionUtils.isEmpty(cartProdEntityUpdated)) {
				model.addAttribute("upe", cartProdEntityUpdated);
				modelMap.put("userid", userId);
				// return "USER_CART";
			}
		}*/
		
		
		 modelMap.put("productsRemoved", "All products from your cart removed. please add products to your cart again");
		String urlS = redirectToProdList(userId);
		//return fetchCartDetails(model, modelMap, userId);
		fetchProductList(model, modelMap, userId);
		return "products";
		//return "redirect:" + urlS;
		// return "USER_CART";
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#fetchCartDetails(org.springframework.ui.Model, org.springframework.ui.ModelMap, long)
	 */
	@Override
	public String fetchCartDetails(Model model, ModelMap modelMap, long userId) {
		UsersEntity ueserEntity = userRepo.findUserRByUserId(userId);
		CartEntity cartEntity = ueserEntity.getCartEntity();
		if (null!= cartEntity) {
			
			long us = cartEntity.getCartId();
			List<ProductInCartEntity> cartProdEntity = null!= cartEntity.getUserProductEntity()? cartEntity.getUserProductEntity():null;
			//upe.get(0).get
			if (!CollectionUtils.isEmpty(cartProdEntity)) {
				model.addAttribute("upe", cartProdEntity);
				modelMap.put("userid", userId);
				return "USER_CART";
			} 
			else{
				modelMap.put("noProd", "No product availabale in your cart");
				fetchProductList(model, modelMap, userId);
				return "products";
			}
		}
		/*String urlS = redirectToProdList(userId);
		modelMap.put("noProd", "No product availabale");
		return "redirect:" + urlS;
		*/
		modelMap.put("noProd", "No product availabale in your cart");
		fetchProductList(model, modelMap, userId);
		return "products";
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#increaseItem(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	public String increaseItem(Model model, ModelMap modelMap, long userId, long productId) {
		CartEntity cartEntity = cartRepo.findCartByUserId(userId);
		List<ProductInCartEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<ProductInCartEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				currentCount = currentCount + 1;
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				userProdRepo.save(userProdOptional.get());
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String urlS = url.toString();

		return "redirect:" + urlS;
	}

	/*
	 * (non-Javadoc)
	 * @see com.MindCart.Service.MindCartIF#decreaseItem(org.springframework.ui.Model, org.springframework.ui.ModelMap, long, long)
	 */
	@Override
	public String decreaseItem(Model model, ModelMap modelMap, long userId, long productId) {
		CartEntity cartEntity = cartRepo.findCartByUserId(userId);
		List<ProductInCartEntity> userProd = null != cartEntity && null != cartEntity.getUserProductEntity()
				? cartEntity.getUserProductEntity() : null;
		if (!CollectionUtils.isEmpty(userProd)) {
			Optional<ProductInCartEntity> userProdOptional = userProd.stream()
					.filter(up -> productId == up.getProductId()).findAny();
			if (userProdOptional.isPresent()) {
				int currentCount = userProdOptional.get().getProductCount();
				if (currentCount > 1) {
					currentCount = currentCount - 1;
				} else if (currentCount == 1) {
					removeProductFromCart(model, modelMap, userId, productId, userProd, userProdOptional.get());
					return fetchCartDetails(model, modelMap, userId);
				}
				userProdOptional.get().setProductCount(currentCount);
				
				int price = userProdOptional.get().getPrice();
				int priceToBePaid=price*currentCount;
				userProdOptional.get().setPriceToBePaid(priceToBePaid);
				
				userProdRepo.save(userProdOptional.get());
			}

		}
		StringBuilder url = new StringBuilder("http://localhost:9104/mindcart/cart/");
		url.append(userId);
		String urlS = url.toString();

		return "redirect:" + urlS;
	}

	private void removeProductFromCart(Model model, ModelMap modelMap, long userId, long productId,
			List<ProductInCartEntity> cartProdEntityList, ProductInCartEntity cartProdEntity) {
		cartProdEntityList.remove(cartProdEntity);
		userProdRepo.deleteById(productId);
		//return fetchCartDetails(model, modelMap, userId);
	}
	
	/**
	 * This method is used to add few default user into DB for testing all the functionality
	 * @return UsersEntity
	 */
	private List<UsersEntity> addDefaultUserToDB() {
		List<UsersEntity> users = new ArrayList<>();
		UsersEntity user = addUsersToDBToTestFunctionality("admin", "admin", "Subhankar Guchhait", 25);
		UsersEntity user1 = addUsersToDBToTestFunctionality("rupsha", "rupsha", "Rupsha Mukhuty", 26);
		UsersEntity user2 = addUsersToDBToTestFunctionality("Vaskar", "vaskar", "Vaskar Guchhait", 21);
		users.add(user);
		users.add(user1);
		users.add(user2);
		return users;
	}
	
	private UsersEntity addUsersToDBToTestFunctionality(String userName, String password, String fullName, int age) {
		UsersEntity us = new UsersEntity();
		us.setUserName(userName);
		us.setPassword(password);
		us.setUserFullName(fullName);
		us.setAge(age);
		userRepo.save(us);
		return us;
	}
	
	/**
	 * This method is used to add few products into the product list and user can add these product into their cart
	 */
	private void addProductsIntoProductPage() {
		List<ProductsEntity> prodListEntity = new ArrayList<>();
		prodListEntity.add(addProductIntoDB(501, "REDMI NOTE 10 PRO", "SANDHYA TELECOM", 16999));
		prodListEntity.add(addProductIntoDB(601, "REDMI NOTE 9 PRO", "SANDHYA TELECOM", 10999));
		prodListEntity.add(addProductIntoDB(701, "CHaya prakashani Math Book", "Jaggeswar Book Srtore", 500));
		prodListEntity.add(addProductIntoDB(801, "CHaya prakashani Physics Book", "Jaggeswar Book Srtore", 600));
		prodListEntity.add(addProductIntoDB(901, "Realme 2 PRO", "SANDHYA TELECOM", 12599));

		prodListRepo.saveAll(prodListEntity);
	}
	
	private ProductsEntity addProductIntoDB(long productId, String productName, String sellerName, int price){
		ProductsEntity prodEntity = new ProductsEntity();
		prodEntity.setProductId(productId);
		prodEntity.setProductName(productName);
		prodEntity.setSeller(sellerName);
		prodEntity.setPrice(price);
		return prodEntity;
	}
	
	
	//below method is getting used for this application
	
	@Override
	public String login(ModelMap modelMap, String userName, String password, Model model) {

		String redirectTo = "login";
		UsersEntity user = userRepo.findUserR(userName);
		if (user != null) {
			List<ProductsEntity> prodList = prodListRepo.findAll();

			if (null != prodList) {
				model.addAttribute("prodList", prodList);
			}
			redirectTo = populateUserDetails(modelMap, userName, password, user);
		} else {
			modelMap.put("userNotExist", "User doesn't exist");
		}
		return redirectTo;

	}
	
	//below method is getting used for this application
	private String populateUserDetails(ModelMap model, String userName, String password, UsersEntity user) {
		String redirectTo = "login";
		if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
			CartEntity ce = (null != user.getCartEntity()) ? user.getCartEntity() : null;
			if (null != ce) {
				model.put("productId", ce.getProductId());
				// model.put("productCount", ce.getProductCount());
			}

			model.put("userName", user.getUserFullName());
			redirectTo = "Welcome";
		} else {
			model.put("loginError", "Please enter the correct password");
		}
		return redirectTo;
	}




}
