package com.MindCart.MindCart;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.MindCart.EntityClass.ProductsEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.CartRepository;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UsersRepository;
import com.MindCart.Service.MindCartImpl;
import com.sun.xml.bind.v2.schemagen.xmlschema.Any;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MindCartImplTest {

	@InjectMocks
	private MindCartImpl mi;
	
	@Mock
	private ProductListRepository prodListRepo;
	
	
	@Mock
	private UsersRepository userRepo;
	

	@Mock
	private CartRepository cartRepo;
	
	
	
	//@Test
	public void testMindCartPortal() throws Exception{
		List<ProductsEntity> productListEntity = new ArrayList<>();
		
		
		ProductsEntity productEntity = new ProductsEntity();
		productEntity.setPrice(500);
		productEntity.setProductId(101);
		productEntity.setProductName("MOBILE");
		productEntity.setSeller("ABC");
		productListEntity.add(productEntity);
		
		
		Optional<ProductsEntity> findProduct = productListEntity.stream().filter(pd-> "MOBILE".equalsIgnoreCase(pd.getProductName())).findAny();
		
		Mockito.when(prodListRepo.findById((long) 1)).thenReturn(findProduct);
		
		
		UsersEntity ueserEntity = new UsersEntity();
		ueserEntity.setAge(50);
		ueserEntity.setPassword("password");
		Mockito.when(userRepo.findUserRByUserId(1)).thenReturn(ueserEntity);
		
		mi.addProductToCart(null, null, 1, 500);
		
		
//		this.mockMvc.perform(RequestBuilder.
		
		
		
	}
	
}
