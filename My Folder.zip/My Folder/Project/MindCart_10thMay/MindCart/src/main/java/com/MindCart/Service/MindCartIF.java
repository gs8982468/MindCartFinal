package com.MindCart.Service;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

@Component
public interface MindCartIF {

	/**
	 * This method is used to retrieve the home page of the Mindcart portal
	 * @param model Model
	 */
	void retrieveMindCartHomePage(Model model);
	

	/**
	 * This method is used for fetching users from Database
	 * @param model of Model Type
	 * @param modelMap of ModelMap type
	 * @param userId of type Long
	 */
	void fetchUserDataFromDB(Model model, ModelMap modelMap, long userId);

	/**
	 * This method is used to add product into user cart
	 * @param model of Model Type
	 * @param modelMap of ModelMap Type
	 * @param userId of type Long
	 * @param productId of type Long
	 * @return String
	 */
	String addProductToCart(Model model, ModelMap modelMap, long userId, long productId) throws Exception;

	/**
	 * This method is used to fetch Cart details of a particular user.
	 * @param model of Model Type
	 * @param modelMap of ModelMap Type
	 * @param userId of type long
	 * @return String
	 */
	String fetchUserCartDetails(Model model, ModelMap modelMap, long userId);

	/**
	 * This method is used to increase number of product item in the cart 
	 * @param model of Model Type
	 * @param modelMap of ModelMap Type
	 * @param userId of Long type
	 * @param productId of Long Type
	 * @return
	 */
	String increaseCartItemsQuantity(Model model, ModelMap modelMap, long userId, long productId) throws Exception, RuntimeException;

	/**
	 * This method is used to decrease number of product item in the cart
	 * @param model of type Model
	 * @param modelMap of type ModelMap
	 * @param userId of type Long
	 * @param productId of type Long
	 * @return
	 */
	String decreaseCartItemsQuantity(Model model, ModelMap modelMap, long userId, long productId)  throws Exception;

	/**
	 * This method is used to remove all products from user cart
	 * @param model of type Model
	 * @param modelMap of type ModelMap
	 * @param userId of type Long
	 * @return
	 */
	String removeUserCartsProducts(Model model, ModelMap modelMap, long userId);
	
	

	/**
	 * This method is used for Log in to mindcart portal
	 * @param modelMap
	 * @param username
	 * @param password
	 * @param model
	 * @return
	 */
	String login(ModelMap modelMap,String username, String password, Model model);
	
	
}
