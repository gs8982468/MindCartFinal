package com.MindCart.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.ProductInUserCartEntity;
import com.MindCart.EntityClass.GlobalProductEntity;
import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.CartRepository;
import com.MindCart.Repository.ProductListRepository;
import com.MindCart.Repository.UserProductRepo;
import com.MindCart.Repository.UsersRepository;
@Component
public interface DBManagementServiceIF {

	

	public UsersEntity findUserByUserId(long userId);

	public UsersEntity findUserByUserName(String userName);
	
	public CartEntity findCartByUserId(long userId);

	public Optional<GlobalProductEntity> findProductDetailsByProductId(long productId) ;
	
	public List<GlobalProductEntity> findAllGlobalProducts();
	
	public List<ProductInUserCartEntity> findAllProductOfUsers(long cartId) ;

	public List<ProductInUserCartEntity> findUsersProduct() ;
	
	public void updateCartEntity(CartEntity cartEntity);

	public void deleteProductFromUserCart(long cartId, long productId);

	public void updateProductsInUserCart(List<ProductInUserCartEntity> cartProductEntity) ;
	
	public void updateProductInUserCart(ProductInUserCartEntity cartProductEntity) ;

	public void updateUserDetails(UsersEntity userEntity);

	public void updateGlobalProductListToDB(List<GlobalProductEntity> prodListEntity) ;
	
	public void deleteByProductIdFromUserCart(long productId) ;
	
}
