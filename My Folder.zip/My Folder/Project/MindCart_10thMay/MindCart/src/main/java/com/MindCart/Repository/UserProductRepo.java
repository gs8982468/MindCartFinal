package com.MindCart.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.MindCart.EntityClass.CartEntity;
import com.MindCart.EntityClass.ProductInUserCartEntity;
import com.MindCart.EntityClass.UsersEntity;

@Repository
public interface UserProductRepo extends JpaRepository<ProductInUserCartEntity, Long>{
	
	/*@Query(value = "select user from UsersEntity user where user.userName=:userName and user.password=:password")
	public UsersEntity findUser(@Param("userName") String userName, @Param("password") String password);
	*/
	/*@Query(value = "select * from MINDCARTUSER where ")
	public UsersEntity findUser(@Param("userName") String userName, @Param("password") String password);*/
	
	@Query(value = "select * from USERS user where user.USER_NAME= ?", nativeQuery=true)
	public UsersEntity findUserR(String userId);
	
	@Query(value = "select * from CART_PRODUCT up where up.CART_ID=?", nativeQuery=true)
	public List<ProductInUserCartEntity> findAllProductOfUser(long cartId);

	@Query(value = "select * from USERS user where user.USER_ID= ?", nativeQuery=true)
	public UsersEntity findUserRByUserId(long userId);
	
	
	@Modifying
	@Query(value = "Delete CART_PRODUCT where CART_ID= ?1 and PRODUCT_ID=?2", nativeQuery=true)
	public void deleteProductFromUserCart(long cartId, long productId);

}
