package com.MindCart.MindCart;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.UsersRepository;
import com.MindCart.Service.MindCartImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment= WebEnvironment.RANDOM_PORT)
class MindCartApplicationTests {

	private MockMvc mockMvc;
	
	@Autowired
	private MindCartImpl mi;
	
	
	@Autowired
	private UsersRepository userRepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void testMindCartPortal() throws Exception{
		
		UsersEntity ueserEntity = new UsersEntity();
		ueserEntity.setAge(50);
		ueserEntity.setPassword("password");
		Mockito.when(userRepo.findUserRByUserId(1)).thenReturn(ueserEntity);
		
		mi.addProductToCart(null, null, 1, 500);
		
		
//		this.mockMvc.perform(RequestBuilder.
		
		
		
	}

}
