package com.MindCart;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.util.CollectionUtils;

import com.MindCart.EntityClass.UsersEntity;
import com.MindCart.Repository.UsersRepository;

@SpringBootApplication
public class MindCartApplication {

	/*@Bean
	public UsersRepository getUserRepo(){
		return new UsersRepository();
	}*/
	private static UsersRepository ur;

	
	public static void main(String[] args) {
		SpringApplication.run(MindCartApplication.class, args);
	}
	
	/*static{
		List<UsersEntity> users = ur.findAll();
	    users = (!CollectionUtils.isEmpty(users)) ? users : new ArrayList<>();
	    UsersEntity user = new UsersEntity();
	    user.setUserId("admin");
		user.setPassword("admin");
		user.setAge("50");
		ur.saveAll(users);
		
	}*/

}
